#pragma once

#define XDIM 16384
#define YDIM 256

void ComputeLaplacian(float **u, float **Lu);
