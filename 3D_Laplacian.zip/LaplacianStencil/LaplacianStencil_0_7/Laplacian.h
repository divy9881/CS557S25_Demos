#pragma once

#define XDIM 2048
#define YDIM 2048

void ComputeLaplacian(float **u, float **Lu);
