#pragma once

#include "Parameters.h"

float MergedLine13(const float (&x)[XDIM][YDIM][ZDIM], float (&z)[XDIM][YDIM][ZDIM]);