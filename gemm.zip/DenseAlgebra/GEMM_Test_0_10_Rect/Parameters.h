#pragma once

#ifndef MATRIX_SIZE_1
#define MATRIX_SIZE_1 1024
#endif

#ifndef MATRIX_SIZE_2
#define MATRIX_SIZE_2 2048
#endif

#ifndef MATRIX_SIZE_3
#define MATRIX_SIZE_3 1024
#endif

#ifndef BLOCK_SIZE
#define BLOCK_SIZE 64
#endif
